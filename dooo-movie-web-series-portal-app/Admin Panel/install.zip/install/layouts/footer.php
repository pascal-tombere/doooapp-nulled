<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                © <?php echo date("Y"); ?> Dooo<span class="d-none d-sm-inline-block"> - Crafted with <i
                        class="mdi mdi-heart text-danger"></i></span>
            </div>
        </div>
    </div>
</footer>